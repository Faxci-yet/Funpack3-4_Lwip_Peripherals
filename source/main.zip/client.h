#ifndef _CLIENT_H_
#define _CLIENT_H_

void client_init1(void);

#endif /* _CLIENT_H_ */
